from extra.install.framework import yx

yx.run()